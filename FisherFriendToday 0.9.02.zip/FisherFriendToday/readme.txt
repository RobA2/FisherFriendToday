v0.3.85 alpha 2025-02-03
[notes are pretty much the same for future builds, but heres the first write up]
Very raw... very alpha, but stable :) So far only works with slash command in game.
Planning to have an interface for options and titan bar, but that all depends on wow patch 11.1 changes.
(and how well I can learn to code lua) :)
I'm open to suggestions , with one exception...
**    This addon will ONLY show directions/locations for the fisherfriends :)    **
There are already addons that check the fish and currencies,
as well as addons that track your rep for the fisherfriends....
 Legion came out in 2016. Patch 7.3.0: Shadows of Argus, Aug 2017 had the Fisherfriends.
The whole time I kept wondering why no one wrote an addon to give directions to the npc's ...
and so after 8-ish years I finally got to wondering why "I" hadn't written it yet...
In so many ways... the simplicity to their rotation, is also funky enough for coding;
 No wonder no one else had written it... and yet, having done it... I honestly think it's because no one
 saw a need as an addon. Less time looking up a website to see where to go :)
Glad that I wrote this and want to expand on it... at least to the point of looking better :)
Patch 11.1 is apparently going to introduce better event tracking, so this whole addon might be bust.
Then again... it might be the one addon that addresses the 10 year old issue of finding
the Fisherfriend of the day :)